<?php
session_start();
 if ($_GET['password'] == "XB"){
      }
else{
    header('Location: HHHHHHHHHHHHH.php');
    }
?>